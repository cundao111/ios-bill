# 上传并生成未签名 IPA

## 一、上传项目

1. 解压 `简账-iOS-GitHub构建包.zip`。
2. 在 GitHub 新建一个空仓库，建议仓库名称填写 `SimpleLedger`。
3. 进入空仓库，点击 **uploading an existing file** 或 **Add file → Upload files**。
4. 将解压出来的全部内容上传到仓库根目录。
5. 确认仓库根目录能直接看到：
   - `.github`
   - `SimpleLedger`
   - `SimpleLedger.xcodeproj`
6. 提交上传，分支使用 `main` 或 `master`。

> 不要只上传 ZIP 文件。GitHub 不会自动解压 ZIP，工作流也就无法运行。

## 二、下载 IPA

1. 打开仓库顶部的 **Actions**。
2. 首次使用时，如页面提示工作流被禁用，点击启用。
3. 打开 **构建未签名 IPA** 工作流。
4. 如果上传代码后没有自动运行，点击 **Run workflow**。
5. 等待构建显示绿色对勾。
6. 打开这次构建记录，在页面底部 **Artifacts** 下载 `SimpleLedger-unsigned-ipa`。
7. 下载得到的是压缩包，解压后即可获得 `SimpleLedger-unsigned.ipa`。

该 IPA 没有签名，需要使用你自己的证书、描述文件和签名工具处理后才能安装。
